# Hasee K670D Hackintosh

## #前言

这款机子前前后后不知道折腾了多少个日夜，从一个完全不知道如何配置的小白慢慢的，变得越来熟练，其中经历了很多，也收获满满。

## #电脑配置

- 型号：神舟K67D G4D1
- 操作系统：macOS Catalina 10.15.3
- 处理器：**8700es QN8H**
- 硬盘：**Samsung PM961**
- 显卡：英特尔 HD Graphics 630
- 声卡：Realtek ALC269VC (0x0269)
- 网卡：**Bcm94352z**



**加粗部分表示更换过配件**

BIOS更新至d大最新

BIOS中关闭CFG锁

核显使用的7代cpu核显驱动id，使用8代核显id发现不能亮度调节

此配置7代u同样适用，本子所用的模具相同即可

## #什么有效

- 核显
- 声音
- 触摸板（部分手势不能用 无解）
- USB端口
- LAN/以太网
- WIFI/蓝牙
- 睡眠（可正常唤醒）
- HDMI/HDMI音频
- 亮度调节
- 原生态电源管理/变频



## #什么无效
 - 开机插入hdmi，显示器亮屏，内建显示器黑屏，模式切换镜像显示，一切正常



## #更新

19/08/11 -- 初次提交

20/01/11 
-- 使用opencore引导，更上时代的潮流

   主要是很多最新插件慢慢的直接集成代opencore里了
 
 -- 使用opencore引导，变频直接最大睿频，插适配器一直显示电池问题


## #截图

![截屏2020-02-04上午9.07.39.png](https://i.loli.net/2020/02/04/7SeCcnwBrDTkb5j.png)

![截屏2020-02-04上午9.15.56.png](https://i.loli.net/2020/02/04/NLMEYUg2Sdc6D18.png)

![截屏2020-02-04上午9.08.56.png](https://i.loli.net/2020/02/04/892XnIDEr7hWT6F.png)

![截屏2020-02-04上午9.11.11.png](https://i.loli.net/2020/02/04/myTcfS2EUpGhsiB.png)

![截屏2020-02-04上午9.08.42.png](https://i.loli.net/2020/02/04/bfHSxzTaO5DJmpe.png)

![WechatIMG2.jpeg](https://i.loli.net/2020/02/04/TXJlkZHRBS1thsU.jpg)

## #其他

